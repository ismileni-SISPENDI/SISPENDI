import 'package:flutter/material.dart';

class RoleSelectionScreen extends StatelessWidget {
  const RoleSelectionScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Mengubah background menjadi Hijau sesuai gambar FlutterFlow
      backgroundColor: const Color(0xFF39B54A), 
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Judul SISPENDI warna Merah
              const Text(
                'SISPENDI',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 36,
                  fontWeight: FontWeight.bold,
                  color: Colors.red, // Warna merah sesuai screenshot
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 30),

              // Wadah Putih di Tengah untuk Logo (Sesuai Kotak Logo di gambar)
              Center(
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.school, // Sementara pakai icon, nanti bisa diganti Image
                    size: 50,
                    color: Color(0xFF39B54A),
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // 3 Tombol Pilihan Pengguna Sesuai Urutan Gambar Anda
              _buildRoleButton(context, 'GURU', const Color.fromARGB(255, 200, 209, 166)), // Warna Pink
              const SizedBox(height: 16),
              _buildRoleButton(context, 'ADMIN', const Color(0xFFEC407A)), // Warna Pink
              const SizedBox(height: 16),
              _buildRoleButton(context, 'ORANG TUA', const Color(0xFFFFB74D)), // Warna Oranye/Kuning
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRoleButton(BuildContext context, String roleName, Color buttonColor) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 16),
        backgroundColor: buttonColor,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8), // Lebih kotak sesuai FlutterFlow
        ),
        elevation: 2,
      ),
      onPressed: () {
        Navigator.pushNamed(
          context, 
          '/login', 
          arguments: roleName,
        );
      },
      child: Text(
        roleName,
        style: const TextStyle(
          fontSize: 20, 
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    );
  }
}