package com.example.sispendi_uas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
